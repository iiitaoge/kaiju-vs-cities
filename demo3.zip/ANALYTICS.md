# Analytics 接入

本项目同时使用两套分析能力，职责不混用：

- GameAnalytics：服务器确认后的技术行为、玩法行为和资源流入/流出。
- Roblox `AnalyticsService`：原生 `SessionLoad` 漏斗。

## GameAnalytics 配置

在 Studio 中选中 `ServerStorage`，添加以下 Attributes：

| Attribute | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `GameAnalyticsGameKey` | String | 是 | GameAnalytics 游戏 Key，32 位字母或数字 |
| `GameAnalyticsSecretKey` | String | 是 | GameAnalytics Secret Key，40 位字母或数字 |
| `GameAnalyticsBuild` | String | 否 | 数据 Build；缺省为 `0.1.0`，正式发布时应显式设置 |
| `GameAnalyticsDebug` | Boolean | 否 | 是否开启 SDK Info Log；缺省为 `false` |

凭据不进入源码。任一凭据缺失或格式不正确时，GameAnalytics 会保持关闭，玩法不受影响。当前 Place 已开启 HTTP Requests；复制到其他 Place 时也必须开启。

## 原生加载漏斗

漏斗名为 `SessionLoad`，每次玩家加入使用独立的 `FunnelSessionId`：

1. `Player Joined`
2. `Save Ready`
3. `Playable`

`Playable` 只有在存档、Plot、City、Monster 和 Character placement 全部成功后才记录。各并行加载项的成功、失败和耗时进入 GameAnalytics 技术行为，不作为原生漏斗步骤，避免 Roblox 自动补齐被跳过步骤时产生错误结果。

Roblox 原生漏斗只会从服务器发送，并且只有已发布体验会形成线上数据；Studio 运行用于验证调用链和错误，不代表 Creator Dashboard 已收到事件。

## GameAnalytics 事件范围

- 技术行为：加入、存档与各运行时阶段、整体 Playable、失败原因和耗时。
- 玩法行为：区域解锁/升级、Boost、手动领取、怪兽建造、攻击开始/完成/拒绝、摧毁奖励。
- 安全行为：服务器网络边界拒绝，按玩家、入口和原因聚合 60 秒。
- 资源数值：`Money` 的 `Income`、`Region`、`Boost`、`Monster`、`Combat` Source/Sink；自动收入按区域聚合 60 秒。

数值尚未定稿不影响接入。以后修改正式数值时，埋点读取的是服务器最终提交的实际金额，不需要在分析层复制一份数值配置。

## SDK 来源

仓库内置官方 GameAnalytics Roblox SDK，版本 `2.2.6`：

- 仓库：`https://github.com/GameAnalytics/GA-SDK-ROBLOX`
- 固定提交：`f391708741f4620f26d5dcbc7fd445b7637893b2`
- 本地目录：`src/Shared/Vendor/GameAnalytics`
- 许可证：`src/Shared/Vendor/GameAnalytics/LICENSE.txt`
